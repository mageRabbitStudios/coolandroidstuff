package com.mini.living.testing.instrumented

abstract class GWTEspressoTest {

    fun given(step: () -> Unit) {
        step()
    }

    fun whenever(step: () -> Unit) {
        step()
    }

    fun then(step: () -> Unit) {
        step()
    }

    fun and(step: () -> Unit) {
        step()
    }
}
