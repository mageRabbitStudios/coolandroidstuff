package com.mini.living.testing.instrumented.espresso

import androidx.test.espresso.IdlingResource
import androidx.test.espresso.IdlingResource.ResourceCallback
import androidx.test.espresso.ViewAssertion
import androidx.test.espresso.ViewInteraction
import android.view.View
import junit.framework.AssertionFailedError

internal class PollingTimeoutIdler(
    viewInteraction: ViewInteraction,
    private val viewAssertion: ViewAssertion,
    private val timeout: Long
) : IdlingResource {

    private val startTime: Long = System.currentTimeMillis()
    private lateinit var callback: ResourceCallback
    private var testView: View? = null

    init {
        viewInteraction.check { view, _ -> testView = view }
    }

    override fun getName(): String {
        return javaClass.simpleName
    }

    override fun isIdleNow(): Boolean {
        val elapsed = System.currentTimeMillis() - startTime
        val timedOut = elapsed >= timeout

        val idle = testView() || timedOut
        if (idle) {
            callback.onTransitionToIdle()
        }

        return idle
    }

    private fun testView(): Boolean {
        return if (testView != null) {
            try {
                viewAssertion.check(testView, null)
                true
            } catch (ex: AssertionFailedError) {
                false
            }
        } else {
            false
        }
    }

    override fun registerIdleTransitionCallback(callback: ResourceCallback) {
        this.callback = callback
    }
}