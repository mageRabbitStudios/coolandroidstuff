package com.mini.living.testing.instrumented

import android.app.Activity
import android.content.Intent
import android.preference.PreferenceManager
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule

/**Custom ActivityTest rule that we use in our app which clears preferences when app is restarting.*/
class ClearedPrefsActivityTestRule<GIVEN_ACTIVITY : Activity>(
    activity: Class<GIVEN_ACTIVITY>,
    initialTouchMode: Boolean,
    launchActivity: Boolean
) : ActivityTestRule<GIVEN_ACTIVITY>(activity, initialTouchMode, launchActivity) {

    private var restarting = false

    override fun beforeActivityLaunched() {
        super.beforeActivityLaunched()

        if (!restarting) {
            PreferenceManager.getDefaultSharedPreferences(
                    InstrumentationRegistry.getInstrumentation().targetContext
            ).apply {
                edit().clear().apply()
            }

            restarting = false
        }
    }

    override fun afterActivityFinished() {
        super.afterActivityFinished()

        if (restarting) {
            launchActivity(Intent())
        }
    }

    fun restartActivity() {
        restarting = true
        finishActivity()
    }
}