package com.mini.living.testing.instrumented.matchers

import android.app.Activity
import android.graphics.drawable.ColorDrawable
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.IdRes
import androidx.core.widget.NestedScrollView
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.ViewAssertion
import androidx.test.espresso.ViewInteraction
import androidx.test.espresso.action.ScrollToAction
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.BoundedMatcher
import androidx.test.espresso.matcher.RootMatchers
import androidx.test.espresso.matcher.ViewMatchers
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.snackbar.SnackbarContentLayout
import com.google.android.material.textfield.TextInputLayout
import com.mini.living.testing.instrumented.WaitDelays
import com.mini.living.testing.instrumented.espresso.PollingTimeoutIdler
import com.mini.living.testing.instrumented.matchers.RecyclerViewMatcher.Factory.withRecyclerView
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers
import org.hamcrest.TypeSafeMatcher
object TestMatchers {

    fun isPasswordHidden(): Matcher<View> {
        return object : BoundedMatcher<View, EditText>(EditText::class.java) {
            override fun describeTo(description: Description) {
                description.appendText("Password is hidden")
            }

            override fun matchesSafely(editText: EditText): Boolean {
                return editText.transformationMethod is PasswordTransformationMethod
            }
        }
    }

    fun getTextInputLayoutHint(@IdRes id: Int): String {
        return getTextInputLayoutHint(ViewMatchers.withId(id))
    }

    private fun getTextInputLayoutHint(matcher: Matcher<View>): String {
        val stringHolder: Array<String?> = arrayOf(null)
        Espresso.onView(matcher).perform(object : ViewAction {
            override fun getDescription(): String {
                return "getting hint from a TextInputLayout"
            }

            override fun getConstraints(): Matcher<View> {
                return ViewMatchers.isAssignableFrom(TextInputLayout::class.java)
            }

            override fun perform(uiController: UiController?, view: View?) {
                val tv = view as TextInputLayout
                stringHolder[0] = tv.hint.toString()
            }
        })
        return stringHolder.first()!!
    }

    private fun withHint(text: String): Matcher<View> {
        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
            }

            override fun matchesSafely(view: View): Boolean {
                if (view !is TextInputLayout) {
                    return false
                }

                val error = view.hint ?: return false
                val hint = error.toString()
                return text == hint
            }
        }
    }

    private fun withTotalItems(expectedItems: Int): Matcher<View> {
        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
            }

            override fun matchesSafely(view: View): Boolean {
                if (view !is androidx.recyclerview.widget.RecyclerView) {
                    return false
                }

                return view.adapter?.itemCount == expectedItems
            }
        }
    }

    private fun withNumChildren(expectedItems: Int): Matcher<View> {
        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
            }

            override fun matchesSafely(view: View): Boolean {
                if (view !is ViewGroup) {
                    return false
                }

                return view.childCount == expectedItems
            }
        }
    }

    private fun withTextColour(expectedColour: Int): Matcher<View> {
        return object : BoundedMatcher<View, TextView>(TextView::class.java) {
            override fun describeTo(description: Description) {
                description.appendText("Check for text colour")
            }

            override fun matchesSafely(textView: TextView): Boolean {
                return textView.currentTextColor == expectedColour
            }
        }
    }

    private fun withSnackbarBackgroundColour(expectedColour: Int): Matcher<View> {
        return object : BoundedMatcher<View, TextView>(TextView::class.java) {
            override fun describeTo(description: Description) {
                description.appendText("Check for background colour")
            }

            override fun matchesSafely(textView: TextView): Boolean {
                val snackbarContentLayout = textView.parent as SnackbarContentLayout
                val snackbarLayout = snackbarContentLayout.parent as Snackbar.SnackbarLayout
                val background = snackbarLayout.background as ColorDrawable
                return background.color == expectedColour
            }
        }
    }

    private fun hasTextInputLayoutErrorText(expectedErrorText: String): Matcher<View> {
        return object : BoundedMatcher<View, TextInputLayout>(TextInputLayout::class.java) {

            override fun describeTo(description: Description?) {
                description?.appendText("Check for text input layout error text")
            }

            override fun matchesSafely(item: TextInputLayout?): Boolean {
                return item?.error.toString() == expectedErrorText
            }
        }
    }

    private fun hasTextInputLayoutErrorEnabled(isErrorEnabled: Boolean): Matcher<View> {
        return object : BoundedMatcher<View, TextInputLayout>(TextInputLayout::class.java) {

            override fun describeTo(description: Description?) {
                description?.appendText("Check for text input layout error enabled")
            }

            override fun matchesSafely(item: TextInputLayout?): Boolean {
                return item?.isErrorEnabled == isErrorEnabled
            }
        }
    }

    /**
     * Perform action of waiting for a specific time.
     */
    fun waitFor(millis: Long): ViewAction {
        return object : ViewAction {
            override fun getConstraints(): Matcher<View> {
                return ViewMatchers.isRoot()
            }

            override fun getDescription(): String {
                return "Wait for $millis milliseconds."
            }

            override fun perform(uiController: UiController, view: View) {
                uiController.loopMainThreadForAtLeast(millis)
            }
        }
    }

    fun iWaitFor(viewInteraction: ViewInteraction, viewAssertion: ViewAssertion, timeout: Long) {
        waitFor(viewInteraction, viewAssertion, timeout)
    }

    fun waitFor(viewInteraction: ViewInteraction, viewAssertion: ViewAssertion, timeout: Long) {
        val idler = PollingTimeoutIdler(viewInteraction, viewAssertion, timeout)
        Espresso.registerIdlingResources(idler)
        viewInteraction.check(viewAssertion)
        Espresso.unregisterIdlingResources(idler)
    }

    fun scrollTo(): ViewAction {
        return object : ViewAction {
            override fun getConstraints(): Matcher<View> {
                return Matchers.allOf(ViewMatchers.withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE), ViewMatchers.isDescendantOfA(Matchers.anyOf(
                        ViewMatchers.isAssignableFrom(ScrollView::class.java),
                        ViewMatchers.isAssignableFrom(HorizontalScrollView::class.java),
                        ViewMatchers.isAssignableFrom(NestedScrollView::class.java),
                        ViewMatchers.isAssignableFrom(RecyclerView::class.java),
                        ViewMatchers.isAssignableFrom(FrameLayout::class.java)))
                )
            }

            override fun getDescription(): String {
                return "Scrolling to view"
            }

            override fun perform(uiController: UiController, view: View) {
                ScrollToAction().perform(uiController, view)
            }
        }
    }

    fun thenToastMessageDisplayed(message: String, activity: Activity) {
        Espresso.onView(ViewMatchers.withText(message))
                .inRoot(RootMatchers.withDecorView(
                        Matchers.not(Matchers.`is`(activity.window.decorView))))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
    }

    fun iSeeToastMessageDisplayed(message: String, activity: Activity) {
        thenToastMessageDisplayed(message, activity)
    }

    // TODO: For dialog matchers look to RBS

    fun viewIsDisplayed(@IdRes id: Int, withScroll: Boolean = true, waitDelay: Long = 0) {
        if (withScroll) {
            iScrollTo(id)
        }

        isViewDisplayed(ViewMatchers.withId(id), true, waitDelay)
    }

    fun viewIsNotDisplayed(@IdRes id: Int, waitDelay: Long = 0) =
            isViewDisplayed(ViewMatchers.withId(id), false, waitDelay)

    fun nestedViewIsDisplayed(@IdRes containerId: Int, @IdRes nestedViewId: Int) =
            isViewDisplayed(Matchers.allOf(ViewMatchers.withId(nestedViewId), ViewMatchers.isDescendantOfA(ViewMatchers.withId(containerId))), true)

    fun nestedViewIsNotDisplayed(@IdRes containerId: Int, @IdRes nestedViewId: Int) =
            isViewDisplayed(Matchers.allOf(ViewMatchers.withId(nestedViewId), ViewMatchers.isDescendantOfA(ViewMatchers.withId(containerId))), false)

    fun nestedViewExists(@IdRes containerId: Int, @IdRes nestedViewId: Int): Boolean =
            Matchers.allOf(ViewMatchers.withId(nestedViewId), ViewMatchers.isDescendantOfA(ViewMatchers.withId(containerId))).matches(Matchers.notNullValue())

    private fun isViewDisplayed(matcher: Matcher<View>, shouldBeVisible: Boolean, waitDelay: Long = 0) {
        val expectedAlpha = if (shouldBeVisible) 1F else 0F
        if (waitDelay == 0L) {
            Espresso.onView(matcher).check(ViewAssertions.matches(Matchers.anyOf(Matchers.not(ViewMatchers.isDisplayed()), ViewMatchers.withAlpha(expectedAlpha))))
        } else {
            iWaitFor(Espresso.onView(matcher), ViewAssertions.matches(Matchers.anyOf(Matchers.not(ViewMatchers.isDisplayed()), ViewMatchers.withAlpha(expectedAlpha))), waitDelay)
        }
    }

    fun thenDoesNotExist(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.doesNotExist())
    }

    fun thenInputHasHint(@IdRes id: Int, text: String) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(withHint(text)))
    }

    fun thenHasTextIgnoringCase(@IdRes id: Int, text: String) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.withText(Matchers.equalToIgnoringCase(text))))
    }

    fun viewHasText(@IdRes id: Int, text: String) {
        iScrollTo(id)
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.withText(text)))
    }

    fun nestedViewHasText(@IdRes containerId: Int, @IdRes nestedViewId: Int, expectedText: String) {
        Espresso.onView(Matchers.allOf(ViewMatchers.withId(nestedViewId), ViewMatchers.isDescendantOfA(ViewMatchers.withId(containerId)))).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
    }

    fun thenContainsText(@IdRes id: Int, text: String) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.withText(Matchers.containsString(text))))
    }

    fun thenHasText(@IdRes id: Int, textId: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.withText(textId)))
    }

    fun thenHasText(@IdRes id: Int, text: String) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.withText(text)))
    }

    fun isChecked(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.isChecked()))
    }

    fun isNotChecked(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.isNotChecked()))
    }

    fun isDisabled(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(Matchers.not(ViewMatchers.isEnabled())))
    }

    fun isEnabled(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.isEnabled()))
    }

    /**
     * Custom click action that can click on views that are only 1% visible
     */
    fun iClick(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).perform(object : ViewAction {

            override fun getConstraints(): Matcher<View> {
                return ViewMatchers.isDisplayingAtLeast(1)
            }

            override fun getDescription(): String {
                return ViewActions.click().description
            }

            override fun perform(uiController: UiController?, view: View?) {
                ViewActions.click().perform(uiController, view)
            }
        })
    }

    fun iScrollTo(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).perform(scrollTo())
    }

    fun iClickOverflowMenuItem(@IdRes id: Int) {
        Espresso.openContextualActionModeOverflowMenu()
        Espresso.onView(ViewMatchers.withText(id)).perform(ViewActions.click())
    }

    fun iSwipeToRefresh(@IdRes id: Int) {
        iScrollTo(id)
        Espresso.onView(ViewMatchers.withId(id)).perform(object : ViewAction {
            override fun getDescription(): String {
                return ViewActions.swipeDown().description
            }

            override fun getConstraints(): Matcher<View> {
                return ViewMatchers.isDisplayingAtLeast(1)
            }

            override fun perform(uiController: UiController?, view: View?) {
                ViewActions.swipeDown().perform(uiController, view)
            }
        })
    }

    fun iEnterText(
        viewId: Int,
        text: String,
        closeKeyboard: Boolean = true
    ) {
        iScrollTo(viewId)
        Espresso.onView(ViewMatchers.withId(viewId)).perform(ViewActions.typeText(text))

        if (closeKeyboard) {
            Espresso.closeSoftKeyboard()
        }
    }

    fun iClearText(viewId: Int) {
        Espresso.onView(ViewMatchers.withId(viewId)).perform(ViewActions.clearText())
    }

    fun thenHasFocus(@IdRes id: Int) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(ViewMatchers.hasFocus()))
    }

    fun thenListHasTotalItems(recyclerViewId: Int, expectedTotalItems: Int) {
        Espresso.onView(ViewMatchers.withId(recyclerViewId)).check(ViewAssertions.matches(withTotalItems(expectedTotalItems)))
    }

    fun thenListItemHasText(recyclerViewId: Int, position: Int, childViewId: Int, text: String) {
        Espresso.onView(withRecyclerView(recyclerViewId)
                .atPositionOnView(position, childViewId))
                .check(ViewAssertions.matches(ViewMatchers.withText(text)))
    }

    fun thenViewHasTotalChildren(viewId: Int, expectedItems: Int) {
        Espresso.onView(ViewMatchers.withId(viewId)).check(ViewAssertions.matches(withNumChildren(expectedItems)))
    }

    fun iScrollToItemInList(recyclerViewId: Int, position: Int) {
        Espresso.onView(ViewMatchers.withId(recyclerViewId))
                .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(position))
    }

    fun iScrollToItemInList(recyclerViewId: Int, startPosition: Int, endPosition: Int) {
        for (pos in startPosition..endPosition) {
            iScrollToItemInList(recyclerViewId, pos)
        }
    }

    fun iClickItemInList(recyclerViewId: Int, position: Int) {
        Espresso.onView(withRecyclerView(recyclerViewId)
                .atPositionOnView(position, -1))
                .perform(ViewActions.click())
    }

    fun thenListItemIsDisplayed(recyclerViewId: Int, position: Int, childViewId: Int) {
        Espresso.onView(withRecyclerView(recyclerViewId)
                .atPositionOnView(position, childViewId))
                .perform(scrollTo())
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
    }

    fun thenListItemIsNotDisplayed(recyclerViewId: Int, position: Int, childViewId: Int) {
        Espresso.onView(withRecyclerView(recyclerViewId)
                .atPositionOnView(position, childViewId))
                .check(ViewAssertions.matches(Matchers.not(ViewMatchers.isDisplayed())))
    }

    fun thenListItemTextIsColour(recyclerViewId: Int, position: Int, childViewId: Int, textColour: Int) {
        Espresso.onView(withRecyclerView(recyclerViewId)
                .atPositionOnView(position, childViewId))
                .check(ViewAssertions.matches(withTextColour(textColour)))
    }

    fun thenSnackbarIsDisplayed(text: Int) {
        thenHasText(com.google.android.material.R.id.snackbar_text, text)
    }

    fun thenSnackbarIsDisplayed(text: String, @ColorInt color: Int) {
        waitFor(Espresso.onView(ViewMatchers.withId(com.google.android.material.R.id.snackbar_text)),
                ViewAssertions.matches(ViewMatchers.withText(text)),
                WaitDelays.MEDIUM)
        waitFor(Espresso.onView(ViewMatchers.withId(com.google.android.material.R.id.snackbar_text)),
                ViewAssertions.matches(withSnackbarBackgroundColour(color)),
                WaitDelays.MEDIUM)
    }

    fun iSeeSnackbarIsDisplayed(text: Int) {
        thenSnackbarIsDisplayed(text)
    }

    fun iSeeASnackbar(text: String, @ColorInt color: Int) {
        thenSnackbarIsDisplayed(text, color)
    }

    fun thenSnackbarClicked() {
        iClick(com.google.android.material.R.id.snackbar_action)
    }

    fun thenTextInputLayoutHasError(@IdRes id: Int, errorText: String) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(hasTextInputLayoutErrorText(errorText)))
    }

    fun thenTextInputLayoutErrorEnabled(@IdRes id: Int, errorEnabled: Boolean) {
        Espresso.onView(ViewMatchers.withId(id)).check(ViewAssertions.matches(hasTextInputLayoutErrorEnabled(errorEnabled)))
    }
}
