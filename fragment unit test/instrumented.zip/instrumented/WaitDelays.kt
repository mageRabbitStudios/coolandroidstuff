package com.mini.living.testing.instrumented

object WaitDelays {

    const val SHORT: Long = 2000
    const val MEDIUM: Long = 5000
    const val LONG: Long = 10000
}