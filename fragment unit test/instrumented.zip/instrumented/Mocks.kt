package com.mini.living.testing.instrumented

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.test.platform.app.InstrumentationRegistry

fun verticalLinearLayoutManagerMock() = LinearLayoutManager(
        InstrumentationRegistry.getInstrumentation().context,
        RecyclerView.VERTICAL,
        false)

